package com.ciberfarma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawiTema03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
