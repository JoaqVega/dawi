package com.ciberfarma.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ciberfarma.model.Producto;
import com.ciberfarma.services.CategoriaService;
import com.ciberfarma.services.ProductoService;
import com.ciberfarma.services.ProveedorService;

@Controller
@RequestMapping("/productos")
public class ProductoController {

	@Autowired
	private ProductoService servicio;
	
	@PostMapping("/grabar")
	public String grabarProd(@ModelAttribute Producto producto, Model model) {
		try {
			servicio.agregarProducto(producto);
			model.addAttribute("mensaje", "Producto" + producto.getDes_prod() + " registrado");
			model.addAttribute("cssmensaje", "alert alert-success");
		} catch (Exception e) {
			model.addAttribute("mensaje", "Error al registrar Producto");
			model.addAttribute("cssmensaje", "alert alert-danger");
		}
		return "crudproductos";
	}
	
	@GetMapping()
	public String cargarPag(Model model) {
		// enviar el listado
		model.addAttribute("lstProductos", servicio.listarProductos());
		//Enviar un objeto de Producto vacío
		model.addAttribute("producto", new Producto());
		//combos
		model.addAttribute("lstCategorias", servicioCat.listarCategorias());
	    model.addAttribute("lstProveedores", servicioProv.listarProveedores());
		return "crudproductos";
	}
	
	@GetMapping("/editar/{id_prod}")
	public String editar(@PathVariable("id_prod") String id_prod, Model model) {
		//Obtener un Producto según el id y enviarlo a la página
		Producto p = servicio.obtenerProductoPorId(id_prod);
		model.addAttribute("producto", p);
		model.addAttribute("lstProductos", servicio.listarProductos());
		// 2da forma
		//model.addAttribute("producto", servicio.obtenerProductoPorId(id_prod));
		// combos
	    model.addAttribute("lstCategorias", servicioCat.listarCategorias());
	    model.addAttribute("lstProveedores", servicioProv.listarProveedores());
		return "crudproductos";
	}
	
	@Autowired
	private CategoriaService servicioCat;

	@Autowired
	private ProveedorService servicioProv;

}




