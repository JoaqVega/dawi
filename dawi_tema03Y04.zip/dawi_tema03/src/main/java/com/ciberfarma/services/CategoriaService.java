package com.ciberfarma.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ciberfarma.model.Categoria;
import com.ciberfarma.repository.ICategoriaRepository;

@Service
public class CategoriaService {

    @Autowired
    private ICategoriaRepository repoCat;

    public List<Categoria> listarCategorias() {
        return repoCat.findAll();
    }
}
