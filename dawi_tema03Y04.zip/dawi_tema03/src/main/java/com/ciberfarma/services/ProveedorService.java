package com.ciberfarma.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ciberfarma.model.Proveedor;
import com.ciberfarma.repository.IProveedorRepository;

@Service
public class ProveedorService {

    @Autowired
    private IProveedorRepository repoProv;

    public List<Proveedor> listarProveedores() {
        return repoProv.findAll();
    }
}
