package com.ciberfarma.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ciberfarma.model.Producto;
import com.ciberfarma.repository.ICategoriaRepository;
import com.ciberfarma.repository.IProductoRepository;

@Service
public class ProductoService {

	@Autowired
	private IProductoRepository repoProd;
	
	public List<Producto> listarProductos() {
		return repoProd.findAll();
	}

	public Producto obtenerProductoPorId(String id) {
		return repoProd.findById(id).orElse(null);
	}

	public Producto agregarProducto(Producto nuevo) {
		return repoProd.save(nuevo);
	}
	
	@Autowired
	private ICategoriaRepository repoCat;

}
